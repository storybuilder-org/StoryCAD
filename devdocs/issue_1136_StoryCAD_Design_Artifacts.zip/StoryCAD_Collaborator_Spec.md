# StoryCAD Collaborator Specification

This document describes the architecture, workflows, and integration points for the StoryCAD Collaborator plugin.

## Overview
- StoryCAD main app (WinUI 3, MVVM)
- Collaborator plugin (Semantic Kernel LLM workflows)
- Proxy (Cloudflare Worker)

Includes:
- API reference
- Data flow diagrams
- Plugin interface definitions
- Testing approach
