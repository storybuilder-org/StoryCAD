# Test Plan for StoryCAD Collaborator

## Unit Tests
- WorkflowRunner logic
- Schema validation

## Integration Tests
- Collaborator ↔ StoryCAD VM sync
- Proxy connection handling

## E2E
- User creates outline → Collaborator generates content → Story updated
