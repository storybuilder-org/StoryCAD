using Microsoft.SemanticKernel;
namespace StoryCAD.Collaborator
{
    public class SkProxyClient
    {
        private readonly HttpClient _client = new();
        public async Task<string> QueryAsync(string prompt)
        {
            var response = await _client.PostAsync("https://proxy.storybuilder.org/api/llm", new StringContent(prompt));
            return await response.Content.ReadAsStringAsync();
        }
    }
}