namespace StoryCAD.Collaborator
{
    public interface ICollaboratorHost
    {
        void UpdateStoryElement(string id, string property, string value);
    }
}