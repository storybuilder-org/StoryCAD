```mermaid
sequenceDiagram
User->>StoryCAD: Open Collaborator
StoryCAD->>Collaborator: Pass active ViewModel
Collaborator->>WorkflowRunner: Execute workflow
WorkflowRunner->>SemanticKernel: Generate prompts
SemanticKernel->>Proxy: Send query
Proxy->>LLM: Forward request
LLM-->>Proxy: Stream response
Proxy-->>Collaborator: Return result
Collaborator-->>StoryCAD: Update ViewModel
```