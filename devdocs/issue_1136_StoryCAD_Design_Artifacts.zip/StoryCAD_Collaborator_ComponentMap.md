```mermaid
graph TD
A[StoryCAD Shell] --> B[Collaborator Window]
B --> C[WorkflowShell.xaml]
C --> D[WorkflowPage.xaml]
D --> E[WorkflowViewModel]
E --> F[CollaboratorService]
F --> G[Semantic Kernel]
G --> H[Cloudflare Proxy]
H --> I[LLM Provider]
```