export default {
  async fetch(request: Request): Promise<Response> {
    const auth = request.headers.get('Authorization');
    if (!auth) return new Response('Unauthorized', {status: 401});
    const body = await request.text();
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer '+YOUR_API_KEY },
      body: body
    });
    return new Response(await res.text(), {status: res.status});
  }
}